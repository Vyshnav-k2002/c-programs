
#include <stdio.h>

int main()
{
    int i,n;
    
    printf("enter the size of the array:-");
    scanf("%d",&n);
    int a[n];
    printf("enter the elements in the array:-");
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
        
    }
    int target;
    printf("enter the target to found:-");
    scanf("%d",&target);
    for(i=0;i<n;i++){
        if(a[i]==target){
            printf("the target found at index %d",i);
            return 0;
        }
        
        
    }
    printf("target not found");

    return 0;
}
