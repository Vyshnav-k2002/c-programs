/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int i,n;
    
    printf("enter the size of the array:");
    scanf("%d",&n);
    printf("enter the elements of the array:");
    int a[n];
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    int fl=-1,sl=-1;
    for(i=0;i<n;i++){
        if(a[i]>fl){
            sl=fl;
            fl=a[i];
            
        }
        else if(a[i]>sl&&a[i]!=fl){
            sl=a[i];
        }
    }
    printf("first largest number:%d",fl);
    printf("second largest number:%d",sl);

    return 0;
}
