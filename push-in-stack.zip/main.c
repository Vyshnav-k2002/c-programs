/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#define N 5

int stack[N];
int top=-1;

void push(int x){
    if(top==N-1){
        printf("the stack is over flow");
        
    }
    else{
        top++;
        stack[top]=x;
    }
}
void printStack(){
    if(top==-1){
        printf("the stack is empty");
        
    }
    else{
        printf("print stack elements\n");
        for(int i=top;i>=0;i--){
            printf("%d\n",stack[i]);
        }
        printf("\n");
    }
}
int main(){
    push(10);
    push(20);
    push(30);
    push(40);
    printStack();
    return 0;
}
