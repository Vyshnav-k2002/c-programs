#include <stdio.h>
#define MAX 100

int stack[MAX];
int top = -1;


void push(int value) {
    if (top < MAX - 1) {
        stack[++top] = value;
        printf("%d pushed onto the stack.\n", value);
    } else {
        printf("Stack overflow!\n");
    }
}


int pop() {
    if (top >= 0) {
        return stack[top--];
    } else {
        printf("Stack underflow!\n");
        return -1;
    }
}


int peek() {
    if (top >= 0) {
        return stack[top];
    } else {
        printf("Stack is empty!\n");
        return -1;
    }
}

int main() {
    push(10);
    push(20);
    push(30);

    printf("Top element is %d\n", peek());
    printf("Popped element is %d\n", pop());
    printf("Top element is %d\n", peek());

    return 0;
}
