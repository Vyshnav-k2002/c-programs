/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    
    int choice;
    float num1,num2,result;
    do{
    
    printf("\n calculater menu");
    printf("\n 1-Addition");
    printf("\n 2-Substaction");
    printf("\n 3-Multiplication");
    printf("\n 4-Division");
    printf("\n 5-Exit");
    printf("\nenter the choice:-");
    scanf("%d",&choice);
    if(choice>=0&&choice<=4){
        printf("enter the 2 numbers:-");
        scanf("%f %f",&num1,&num2);
    }
    switch(choice){
        case 1:
        result=num1+num2;
        printf("%f",result);
           break;
        case 2:
        result=num1-num2;
        printf("%f",result);
           break;
        case 3:
        result=num1*num2;
        printf("%f",result);
           break;
        case 4:
        if(num2!=0){
            result=num1/num2;
            printf("%f",result);
            
        }
        else{
            printf("math error");
        }
        break;
        case 5:
        printf("exit");
           break;
          
     default:
     printf("invalied choice");
        break;
    }
}
while(choice!=5);

    return 0;
}