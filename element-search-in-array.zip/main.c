/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int i,n,a[100];
    printf("enter the size ocf the array:");
    scanf("%d",&n);
    printf("enter the elements of the arrayy:");
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
        
    }
    for(i=0;i<n;i++){
        printf("%d",a[i]);
    }
    int e;
    printf("enter the element to check:");
    scanf("%d",&e);
    for(i=0;i<n;i++){
        if(a[i]==e){
            printf("the element is in the array");
            break;
            
        }
    }
    if(i==n){
        printf("the element not found");
    }
    
    

    return 0;
}
