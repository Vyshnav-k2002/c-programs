#include <stdio.h>

int daysInMonth[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

int isLeapYear(int year) {
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
}

int dayOfYear(int year, int month, int day) {
    if (isLeapYear(year)) {
        daysInMonth[1] = 29;
    }
    
    int dayOfYear = 0;
    for (int i = 0; i < month - 1; i++) {
        dayOfYear += daysInMonth[i];
    }
    dayOfYear += day;

    return dayOfYear;
}

int main() {
    int year, month, day;
    printf("Enter date (yyyy mm dd): ");
    scanf("%d %d %d", &year, &month, &day);

    int result = dayOfYear(year, month, day);
    printf("Day number of the year: %d\n", result);

    return 0;
}
