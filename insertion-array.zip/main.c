#include <stdio.h>
#define MAX 100
int main()
{
    int a[MAX],i,n;
    printf("enter the size of the array:");
    scanf("%d",&n);
    
    printf("enter the elements of array:");
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    for(i=0;i<n;i++){
    printf("%d",a[i]);
    }
    int pos,ele;
    printf("\nenter the position:");
    scanf("%d",&pos);
    printf("\nenter the element to add:");
    scanf("%d",&ele);
    for(i=n;i>=pos;i--){
        a[i]=a[i-1];
    }
    a[pos-1]=ele;
    n++;
        
    printf("the elements are:");
    for(i=0;i<n;i++){
    printf("%d",a[i]);
    
    }
    return 0;
}

