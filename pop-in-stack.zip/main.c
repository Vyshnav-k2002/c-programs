#include <stdio.h>
#define N 5

int stack[N];
int top=-1;

void push(int x){
    if(top==N-1){
        printf("the stack is over flow\n");
        
    }
    else{
        top++;
        stack[top]=x;
        printf("%d\n",x);
    }
}
void pop(){
    if(top==-1){
        printf("the stack is under flow");
    }
    else{
        int popped=stack[top];
        top--;
        printf("\t%d\n",popped);
    }
}
int main(){
    push(10);
    push(20);
    push(30);
    push(40);
    push(50);
    pop();
    pop();
    return 0;
}