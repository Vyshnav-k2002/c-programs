#include <stdio.h>
#include <limits.h>

int main() {
    int arr[7] = {5, 3, 1, 8, 2, 10, 7}; 
    int largest = INT_MIN;
    int second_largest = INT_MIN;

    for (int i = 0; i < 7; i++) {
        if (arr[i] > largest) {
            second_largest = largest;
            largest = arr[i];
        } else if (arr[i] > second_largest && arr[i] != largest) {
            second_largest = arr[i];
        }
    }

    printf("The second largest element is: %d\n", second_largest);

    return 0;
}
