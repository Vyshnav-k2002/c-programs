#include <stdio.h>

int main() {
    char str[100];
    
    printf("Enter a positive integer: ");
    scanf("%s", str);

    
    int len = 0;
    while (str[len] != '\0') {
        len++;
    }

    
    while (len > 0 && str[len - 1] == '0') {
        len--;
    }
    str[len] = '\0';

    printf("Without trailing zeros: %s\n", str);

    return 0;
}

    

    



