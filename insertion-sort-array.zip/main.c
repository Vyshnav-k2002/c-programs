/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int i,n,j,temp;
    
    printf("enter the size of the array:");
    scanf("%d",&n);
    printf("enter the elements of the array");
    int a[n];
    for(i=0;i<n;i++){
    scanf("%d",&a[i]);
    }
    for(i=1;i<n;i++){
    temp=a[i];
    j=i-1;
    while(j>=0&&a[j]>temp){
        a[j+1]=a[j];
       j=j-1;
    }
    a[j+1]=temp;

    }
    
    
    for(int k=0;k<n;k++){
        printf("%d",a[k]);
    }
    return 0;
}
