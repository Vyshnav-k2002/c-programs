/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a;
    printf("enter the marks:");
    scanf("%d",&a);
    
    if(a>=90&&a<=100){
        printf("A Grade");
    }
    else if(a>=80&&a<=89){
        printf("B Grade");
    }
    else if(a>=70&&a<=79){
        printf("C Grade");
    }
    else if (a>=60&&a<=69)Grade{
        printf("D ");
    }
    else{
        printf("F Grade");
    }

    return 0;
}
