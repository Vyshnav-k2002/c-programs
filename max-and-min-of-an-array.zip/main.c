#include <stdio.h>
int main()
{
    int n, i;
    printf("Enter the size of the array: ");
    scanf("%d",&n);
    
    int a[n];
    
    printf("Enter the elements of the array: ");
    
    for(i = 0; i < n; i++){
        scanf("%d",&a[i]);
    }
    
    for(i = 0; i < n; i++){
        printf("%d ",a[i]);
    }
    int max=a[0],min=a[0];
    for(i=1;i<n;i++){
        if(a[i]>max){
        
        max=a[i];
        }
        
        if(a[i]<min){
                min=a[i];
            }
        }
             
        
    printf("\nmaximum %d",max);
    printf("\nminimum %d",min);
    
}