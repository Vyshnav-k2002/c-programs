#include <stdio.h>

int main()
{
    int i,n;
    printf("enter the size of the array:");
    scanf("%d",&n);
    printf("enter the elements in the array:");
    int a[n];
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    int sum_even=0,sum_odd=0;
    for(i=0;i<n;i++){
        if(a[i]%2==0){
            sum_even+=a[i];
        }
        else{
            sum_odd+=a[i];
        }
    }
    printf("\n sum of even elemets=%d",sum_even);
    printf("\nsum of odd elements=%d",sum_odd);
}