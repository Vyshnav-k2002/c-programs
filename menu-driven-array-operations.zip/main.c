
#include <stdio.h>
#define max 100
int main()
{
    int a[max],i,n;
    int choice;
    printf("enter the size of the array:");
    scanf("%d",&n);
    
    printf("enter the elements of array:");
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    do{
        printf("\nArray operations");
        printf("\n1-insertion");
        printf("\n2-deletion");
        printf("\n3-search array element");
        printf("\n4-print the array");
        printf("\n5-exit");
        printf("enter the choice");
        scanf("%d",&choice);
        
    
    switch(choice){
        case 1:
         int pos,ele;
    printf("\nenter the position:");
    scanf("%d",&pos);
    printf("\nenter the element to add:");
    scanf("%d",&ele);
    for(i=n;i>=pos;i--){
        a[i]=a[i-1];
    }
    a[pos-1]=ele;
    n++;
        break;
        case 2:
        printf("\nenter the position:");
    scanf("%d",&pos);
    printf("\nenter the element to add:");
    scanf("%d",&ele);
    for(i=n;i>=pos;i--){
        a[i]=a[i-1];
    }
    a[pos-1]=ele;
    n++;
    break;
    case 3:
    int e;
    printf("enter the element to check:");
    scanf("%d",&e);
    for(i=0;i<n;i++){
        if(a[i]==e){
            printf("the number is an element of this array");
            break;
        }
        
    }
    
    if(i==n){
            printf("the number is not in the array");
        }
        break;
        case 4:
       for(i=0;i<n;i++){
           printf("%d",a[i]);
         
       }
             break;
             case 5:
             printf("exit");
             break;
             default:
             printf("invalied choice");
    }
    }
    
   while(choice!=5); 

    return 0;
    }
